import { useEffect, useMemo, useState } from "react";
import Header from "./components/Header";
import ModelStatusBar from "./components/ModelStatusBar";
import StatsRow from "./components/StatsRow";
import CreatePanel from "./components/CreatePanel";
import TaskManager from "./components/TaskManager";
import VideoModal from "./components/VideoModal";
import ParamsModal from "./components/ParamsModal";
import { MODELS } from "./data/models";
import type { GenerationParams, VideoTask } from "./types";
import { genId } from "./utils/format";

const SAMPLE_VIDEOS = [
  "https://interactive-examples.mdn.mozilla.org/media/cc0-videos/flower.mp4",
  "https://interactive-examples.mdn.mozilla.org/media/cc0-videos/VID_20160425_171213.mp4",
];

function buildTask(params: GenerationParams, thumbnailUrl: string | undefined, overrides: Partial<VideoTask> = {}): VideoTask {
  const model = MODELS.find((m) => m.id === params.modelId) ?? MODELS[0];
  const totalGenSeconds = Math.max(3, Math.round(params.durationSec * model.avgGenSeconds));
  const queueWaitSec = model.queueLength > 0 ? Math.min(6, 1 + model.queueLength * 0.6) : 0;
  const now = Date.now();
  return {
    id: genId(),
    createdAt: now,
    updatedAt: now,
    params,
    status: queueWaitSec > 0 ? "queued" : "processing",
    progress: 0,
    etaSeconds: Math.round(totalGenSeconds + queueWaitSec),
    cost: model.costPerSecond * params.durationSec,
    thumbnailUrl,
    queueWaitSec,
    totalGenSeconds,
    ...overrides,
  };
}

function seedTasks(): VideoTask[] {
  const now = Date.now();
  return [
    buildTask(
      {
        prompt: "赛博朋克风格的未来都市夜景，霓虹灯光反射在湿润的街道上，飞行汽车穿梭，电影级运镜",
        negativePrompt: "blurry, low quality, distorted, watermark",
        modelId: "minimax-h3-pro",
        aspectRatio: "16:9",
        durationSec: 8,
        seed: 184022,
        firstFrameName: "cyberpunk_city.jpg",
      },
      "/images/seed-thumb-1.jpg",
      {
        id: genId(),
        status: "completed",
        progress: 100,
        etaSeconds: 0,
        createdAt: now - 1000 * 60 * 42,
        updatedAt: now - 1000 * 60 * 40,
        videoUrl: SAMPLE_VIDEOS[0],
      },
    ),
    buildTask(
      {
        prompt: "宁静的山间湖泊日出航拍，薄雾缭绕水面，金色阳光洒在山峰上",
        negativePrompt: "overexposed, noise, low resolution",
        modelId: "agnes-cinematic",
        aspectRatio: "16:9",
        durationSec: 6,
        seed: 552013,
        firstFrameName: "mountain_lake.jpg",
      },
      "/images/seed-thumb-2.jpg",
      {
        id: genId(),
        status: "completed",
        progress: 100,
        etaSeconds: 0,
        createdAt: now - 1000 * 60 * 25,
        updatedAt: now - 1000 * 60 * 22,
        videoUrl: SAMPLE_VIDEOS[1],
      },
    ),
    buildTask(
      {
        prompt: "动漫风格少女站在屋顶上看夕阳，长发随风飘动，光影细腻",
        negativePrompt: "extra fingers, bad anatomy, text, watermark",
        modelId: "hf-animate-diff",
        aspectRatio: "9:16",
        durationSec: 4,
        seed: 902331,
        firstFrameName: "anime_girl.jpg",
      },
      "/images/seed-thumb-3.jpg",
      {
        id: genId(),
        status: "failed",
        progress: 0,
        etaSeconds: 0,
        createdAt: now - 1000 * 60 * 12,
        updatedAt: now - 1000 * 60 * 11,
        errorMessage: "HuggingFace 推理端点超时（504），请稍后重试或切换模型。",
      },
    ),
    buildTask(
      {
        prompt: "宇航员漂浮在空间站附近，背景是蓝色地球，史诗级光影",
        negativePrompt: "cartoon, low detail",
        modelId: "minimax-h3-standard",
        aspectRatio: "1:1",
        durationSec: 5,
        seed: 110281,
        firstFrameName: "astronaut.jpg",
      },
      "/images/seed-thumb-4.jpg",
      {
        id: genId(),
        status: "processing",
        progress: 46,
        etaSeconds: 16,
        createdAt: now - 1000 * 40,
        updatedAt: now,
      },
    ),
  ];
}

export default function App() {
  const [tasks, setTasks] = useState<VideoTask[]>(() => seedTasks());
  const [selectedModelId, setSelectedModelId] = useState<string>(MODELS[0].id);
  const [playingTask, setPlayingTask] = useState<VideoTask | null>(null);
  const [paramsTask, setParamsTask] = useState<VideoTask | null>(null);

  const currentModel = useMemo(
    () => MODELS.find((m) => m.id === selectedModelId) ?? MODELS[0],
    [selectedModelId],
  );

  const overallStatus = useMemo(() => {
    if (MODELS.some((m) => m.status === "offline")) {
      return MODELS.every((m) => m.status === "offline") ? "offline" : "degraded";
    }
    return MODELS.some((m) => m.status === "degraded") ? "degraded" : "online";
  }, []);

  const activeJobs = tasks.filter((t) => t.status === "queued" || t.status === "processing").length;

  // Simulation ticker: advances queued -> processing -> completed/failed
  useEffect(() => {
    const interval = setInterval(() => {
      setTasks((prev) =>
        prev.map((t) => {
          if (t.status === "queued") {
            const remainingWait = (t.queueWaitSec ?? 0) - 1;
            if (remainingWait <= 0) {
              return {
                ...t,
                status: "processing",
                queueWaitSec: 0,
                updatedAt: Date.now(),
                etaSeconds: t.totalGenSeconds ?? 8,
              };
            }
            return {
              ...t,
              queueWaitSec: remainingWait,
              etaSeconds: Math.max(0, t.etaSeconds - 1),
              updatedAt: Date.now(),
            };
          }

          if (t.status === "processing") {
            const total = t.totalGenSeconds ?? 8;
            const increment = 100 / total;
            const nextProgress = Math.min(100, t.progress + increment);
            const nextEta = Math.max(0, Math.round(((100 - nextProgress) / 100) * total));

            if (nextProgress >= 100) {
              const shouldFail = Math.random() < 0.08;
              if (shouldFail) {
                return {
                  ...t,
                  status: "failed",
                  progress: 0,
                  etaSeconds: 0,
                  updatedAt: Date.now(),
                  errorMessage: "生成失败：模型推理过程中发生错误（已自动释放 GPU 资源），可重试。",
                };
              }
              const sample = SAMPLE_VIDEOS[Math.floor(Math.random() * SAMPLE_VIDEOS.length)];
              return {
                ...t,
                status: "completed",
                progress: 100,
                etaSeconds: 0,
                updatedAt: Date.now(),
                videoUrl: sample,
              };
            }

            return { ...t, progress: nextProgress, etaSeconds: nextEta, updatedAt: Date.now() };
          }

          return t;
        }),
      );
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  function handleGenerate(params: GenerationParams, imageDataUrl?: string) {
    const task = buildTask(params, imageDataUrl);
    setTasks((prev) => [task, ...prev]);
  }

  function handleCancel(id: string) {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  }

  function handleRemove(id: string) {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  }

  function handleRetry(task: VideoTask) {
    const retried = buildTask(task.params, task.thumbnailUrl);
    setTasks((prev) => [retried, ...prev.filter((t) => t.id !== task.id)]);
  }

  return (
    <div className="min-h-screen bg-[#0b0d14] bg-[radial-gradient(circle_at_20%_-10%,rgba(99,102,241,0.12),transparent_40%),radial-gradient(circle_at_90%_10%,rgba(217,70,239,0.1),transparent_35%)] pb-16 text-slate-100">
      <Header overallStatus={overallStatus} activeJobs={activeJobs} />

      <main className="mx-auto flex max-w-[1400px] flex-col gap-6 px-4 pt-6 sm:px-6">
        <ModelStatusBar currentModel={currentModel} />
        <StatsRow tasks={tasks} />
        <CreatePanel modelId={selectedModelId} onModelChange={setSelectedModelId} onGenerate={handleGenerate} />
        <TaskManager
          tasks={tasks}
          onPlay={setPlayingTask}
          onViewParams={setParamsTask}
          onCancel={handleCancel}
          onRetry={handleRetry}
          onRemove={handleRemove}
        />
      </main>

      <footer className="mx-auto mt-10 max-w-[1400px] px-4 text-center text-[11px] text-slate-600 sm:px-6">
        AniFlow · 统一调用 MiniMax H3 (AWS) · Agnes API · HuggingFace · 个人工作台，本地模拟数据仅供演示
      </footer>

      {playingTask && <VideoModal task={playingTask} onClose={() => setPlayingTask(null)} />}
      {paramsTask && <ParamsModal task={paramsTask} onClose={() => setParamsTask(null)} />}
    </div>
  );
}
