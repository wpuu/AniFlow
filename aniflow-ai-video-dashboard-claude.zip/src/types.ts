export type ProviderId = "minimax-h3-aws" | "agnes-api" | "huggingface";

export type BackendStatus = "online" | "degraded" | "offline";

export interface ModelInfo {
  id: string;
  providerId: ProviderId;
  providerName: string;
  name: string;
  description: string;
  costPerSecond: number; // USD per second of generated video
  maxDurationSec: number;
  avgGenSeconds: number; // average seconds to generate 1s of video (speed factor)
  status: BackendStatus;
  latencyMs: number;
  queueLength: number;
}

export type AspectRatio = "16:9" | "9:16" | "1:1" | "4:3";

export type TaskStatus = "queued" | "processing" | "completed" | "failed";

export interface GenerationParams {
  prompt: string;
  negativePrompt: string;
  modelId: string;
  aspectRatio: AspectRatio;
  durationSec: number;
  seed: number;
  firstFrameName?: string;
}

export interface VideoTask {
  id: string;
  createdAt: number;
  updatedAt: number;
  params: GenerationParams;
  status: TaskStatus;
  progress: number; // 0-100
  etaSeconds: number;
  cost: number;
  thumbnailUrl?: string;
  videoUrl?: string;
  errorMessage?: string;
  queueWaitSec?: number;
  totalGenSeconds?: number;
}
