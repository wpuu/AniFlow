import { useRef, useState } from "react";
import { ASPECT_RATIOS, MODELS } from "../data/models";
import type { AspectRatio, GenerationParams } from "../types";
import { cn } from "../utils/cn";
import { formatCost } from "../utils/format";

interface CreatePanelProps {
  modelId: string;
  onModelChange: (id: string) => void;
  onGenerate: (params: GenerationParams, imageDataUrl?: string) => void;
}

const DURATION_OPTIONS = [3, 5, 8, 10];

export default function CreatePanel({ modelId, onModelChange, onGenerate }: CreatePanelProps) {
  const [prompt, setPrompt] = useState("");
  const [negativePrompt, setNegativePrompt] = useState("blurry, low quality, distorted, watermark, text");
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>("16:9");
  const [duration, setDuration] = useState(5);
  const [imagePreview, setImagePreview] = useState<string | undefined>(undefined);
  const [imageName, setImageName] = useState<string | undefined>(undefined);
  const fileRef = useRef<HTMLInputElement>(null);

  const model = MODELS.find((m) => m.id === modelId) ?? MODELS[0];
  const estimatedCost = model.costPerSecond * duration;
  const canSubmit = prompt.trim().length > 0 && model.status !== "offline";

  function handleFile(file?: File) {
    if (!file) return;
    setImageName(file.name);
    const reader = new FileReader();
    reader.onload = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  }

  function handleSubmit() {
    if (!canSubmit) return;
    const params: GenerationParams = {
      prompt: prompt.trim(),
      negativePrompt: negativePrompt.trim(),
      modelId: model.id,
      aspectRatio,
      durationSec: duration,
      seed: Math.floor(Math.random() * 1_000_000),
      firstFrameName: imageName,
    };
    onGenerate(params, imagePreview);
    setPrompt("");
  }

  return (
    <section className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-sm font-semibold tracking-wide text-white">创建新视频</h2>
        <span className="text-[11px] text-slate-500">首帧图 · 提示词 · 模型参数</span>
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-[220px_1fr]">
        {/* Upload first frame */}
        <div>
          <label className="mb-1.5 block text-xs font-medium text-slate-400">首帧图片（可选）</label>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className={cn(
              "group relative flex aspect-video w-full items-center justify-center overflow-hidden rounded-xl border border-dashed border-white/15 bg-black/20 transition hover:border-indigo-400/60 hover:bg-indigo-500/5 lg:aspect-square",
            )}
          >
            {imagePreview ? (
              <>
                <img src={imagePreview} alt="首帧预览" className="h-full w-full object-cover" />
                <span className="absolute inset-0 flex items-center justify-center bg-black/50 text-xs text-white opacity-0 transition group-hover:opacity-100">
                  点击更换
                </span>
              </>
            ) : (
              <div className="flex flex-col items-center gap-1.5 px-3 text-center">
                <svg viewBox="0 0 24 24" fill="none" className="h-6 w-6 text-slate-500" stroke="currentColor" strokeWidth={1.5}>
                  <path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14M4 8h.01M4 4h16a1 1 0 011 1v14a1 1 0 01-1 1H4a1 1 0 01-1-1V5a1 1 0 011-1z" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span className="text-[11px] text-slate-500">点击上传首帧</span>
              </div>
            )}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => handleFile(e.target.files?.[0])}
          />
          {imageName && (
            <div className="mt-1.5 flex items-center justify-between">
              <p className="truncate text-[11px] text-slate-500">{imageName}</p>
              <button
                onClick={() => {
                  setImagePreview(undefined);
                  setImageName(undefined);
                  if (fileRef.current) fileRef.current.value = "";
                }}
                className="text-[11px] text-slate-500 hover:text-rose-400"
              >
                移除
              </button>
            </div>
          )}
        </div>

        {/* Prompts + settings */}
        <div className="flex flex-col gap-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-slate-400">提示词 Prompt</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="描述你想生成的画面，例如：一只金毛犬在海边奔跑，慢动作，电影镜头，黄昏光线"
              rows={3}
              className="w-full resize-none rounded-xl border border-white/10 bg-black/20 px-3 py-2.5 text-sm text-white placeholder:text-slate-600 focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-400/20"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-slate-400">反向提示词 Negative Prompt</label>
            <textarea
              value={negativePrompt}
              onChange={(e) => setNegativePrompt(e.target.value)}
              placeholder="不希望出现的元素，例如：模糊、低质量、畸变"
              rows={2}
              className="w-full resize-none rounded-xl border border-white/10 bg-black/20 px-3 py-2.5 text-sm text-white placeholder:text-slate-600 focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-400/20"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-slate-400">模型选择</label>
              <select
                value={modelId}
                onChange={(e) => onModelChange(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-black/20 px-3 py-2.5 text-sm text-white focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-400/20"
              >
                {MODELS.map((m) => (
                  <option key={m.id} value={m.id} disabled={m.status === "offline"} className="bg-[#111322]">
                    {m.providerName} · {m.name}
                    {m.status === "offline" ? "（离线）" : ""}
                  </option>
                ))}
              </select>
              <p className="mt-1 truncate text-[11px] text-slate-500">{model.description}</p>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium text-slate-400">视频比例</label>
              <select
                value={aspectRatio}
                onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
                className="w-full rounded-xl border border-white/10 bg-black/20 px-3 py-2.5 text-sm text-white focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-400/20"
              >
                {ASPECT_RATIOS.map((a) => (
                  <option key={a.value} value={a.value} className="bg-[#111322]">
                    {a.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium text-slate-400">时长</label>
              <select
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="w-full rounded-xl border border-white/10 bg-black/20 px-3 py-2.5 text-sm text-white focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-400/20"
              >
                {DURATION_OPTIONS.filter((d) => d <= model.maxDurationSec).map((d) => (
                  <option key={d} value={d} className="bg-[#111322]">
                    {d} 秒
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-1 flex flex-col gap-3 border-t border-white/5 pt-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4 text-xs text-slate-400">
              <span>
                预估成本 <span className="font-semibold text-white">{formatCost(estimatedCost)}</span>
              </span>
              <span>
                预计耗时 <span className="font-semibold text-white">~{Math.max(2, Math.round(duration * model.avgGenSeconds))}s</span>
              </span>
            </div>
            <button
              onClick={handleSubmit}
              disabled={!canSubmit}
              className={cn(
                "inline-flex items-center justify-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold transition",
                canSubmit
                  ? "bg-gradient-to-r from-indigo-500 to-fuchsia-500 text-white shadow-lg shadow-indigo-500/25 hover:brightness-110 active:scale-[0.98]"
                  : "cursor-not-allowed bg-white/5 text-slate-500",
              )}
            >
              <svg viewBox="0 0 24 24" fill="none" className="h-4 w-4" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <polygon points="5 3 19 12 5 21 5 3" />
              </svg>
              生成视频
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
