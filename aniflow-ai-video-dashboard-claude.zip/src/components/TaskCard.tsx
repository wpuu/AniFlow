import { MODELS } from "../data/models";
import type { VideoTask } from "../types";
import { formatCost, formatDuration, timeAgo } from "../utils/format";
import TaskStatusBadge from "./TaskStatusBadge";

interface TaskCardProps {
  task: VideoTask;
  onPlay: (task: VideoTask) => void;
  onViewParams: (task: VideoTask) => void;
  onCancel: (id: string) => void;
  onRetry: (task: VideoTask) => void;
  onRemove: (id: string) => void;
}

export default function TaskCard({ task, onPlay, onViewParams, onCancel, onRetry, onRemove }: TaskCardProps) {
  const model = MODELS.find((m) => m.id === task.params.modelId);

  return (
    <div className="group flex flex-col gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-white/20 sm:flex-row">
      {/* Thumbnail / preview */}
      <div className="relative aspect-video w-full shrink-0 overflow-hidden rounded-xl bg-black/30 sm:w-44">
        {task.thumbnailUrl ? (
          <img src={task.thumbnailUrl} alt="首帧" className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-indigo-500/10 to-fuchsia-500/10">
            <svg viewBox="0 0 24 24" fill="none" className="h-6 w-6 text-slate-600" stroke="currentColor" strokeWidth={1.5}>
              <rect x="2" y="4" width="20" height="16" rx="2" />
              <path d="M10 4v4M2 8h20M6 4v4" />
            </svg>
          </div>
        )}
        {task.status === "completed" && (
          <button
            onClick={() => onPlay(task)}
            className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 transition group-hover:opacity-100"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-black">
              <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4 translate-x-[1px]">
                <polygon points="6 3 20 12 6 21 6 3" />
              </svg>
            </span>
          </button>
        )}
        {task.status === "processing" && (
          <div className="absolute inset-x-0 bottom-0 bg-black/40 px-1.5 py-1">
            <div className="h-1 w-full overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-indigo-400 to-fuchsia-400 transition-all"
                style={{ width: `${task.progress}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="flex min-w-0 flex-1 flex-col gap-2.5">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <p className="line-clamp-2 min-w-0 flex-1 text-sm text-slate-200">{task.params.prompt}</p>
          <TaskStatusBadge status={task.status} />
        </div>

        <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-slate-400">
          <span className="inline-flex items-center gap-1">
            <svg viewBox="0 0 24 24" fill="none" className="h-3 w-3" stroke="currentColor" strokeWidth={2}>
              <path d="M12 2a7 7 0 00-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 00-7-7z" />
            </svg>
            {model?.providerName} · {model?.name ?? task.params.modelId}
          </span>
          <span>{task.params.aspectRatio}</span>
          <span>{task.params.durationSec}s</span>
          <span>{timeAgo(task.createdAt)}</span>
        </div>

        {(task.status === "queued" || task.status === "processing") && (
          <div className="flex items-center gap-3">
            <div className="h-1.5 w-full max-w-[220px] overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-indigo-400 to-fuchsia-400 transition-all duration-500"
                style={{ width: `${task.progress}%` }}
              />
            </div>
            <span className="shrink-0 text-xs font-medium text-slate-300">{Math.round(task.progress)}%</span>
            <span className="shrink-0 text-xs text-slate-500">预计剩余 {formatDuration(task.etaSeconds)}</span>
          </div>
        )}

        {task.status === "failed" && task.errorMessage && (
          <p className="rounded-lg border border-rose-500/20 bg-rose-500/5 px-2.5 py-1.5 text-[11px] text-rose-300">
            {task.errorMessage}
          </p>
        )}

        <div className="mt-auto flex flex-wrap items-center justify-between gap-2 pt-1">
          <span className="text-xs text-slate-500">
            成本 <span className="font-semibold text-slate-300">{formatCost(task.cost)}</span>
          </span>
          <div className="flex items-center gap-2">
            {task.status === "completed" && (
              <>
                <button
                  onClick={() => onPlay(task)}
                  className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs text-slate-200 transition hover:bg-white/10"
                >
                  在线播放
                </button>
                <a
                  href={task.videoUrl}
                  download={`aniflow-${task.id}.mp4`}
                  className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs text-slate-200 transition hover:bg-white/10"
                >
                  下载
                </a>
                <button
                  onClick={() => onViewParams(task)}
                  className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs text-slate-200 transition hover:bg-white/10"
                >
                  参数
                </button>
              </>
            )}
            {(task.status === "queued" || task.status === "processing") && (
              <button
                onClick={() => onCancel(task.id)}
                className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs text-slate-300 transition hover:border-rose-400/40 hover:text-rose-300"
              >
                取消
              </button>
            )}
            {task.status === "failed" && (
              <>
                <button
                  onClick={() => onRetry(task)}
                  className="rounded-lg border border-indigo-400/30 bg-indigo-500/10 px-2.5 py-1.5 text-xs text-indigo-300 transition hover:bg-indigo-500/20"
                >
                  重试
                </button>
                <button
                  onClick={() => onViewParams(task)}
                  className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs text-slate-200 transition hover:bg-white/10"
                >
                  参数
                </button>
              </>
            )}
            {(task.status === "completed" || task.status === "failed") && (
              <button
                onClick={() => onRemove(task.id)}
                className="rounded-lg p-1.5 text-slate-500 transition hover:text-rose-400"
                title="删除任务"
              >
                <svg viewBox="0 0 24 24" fill="none" className="h-4 w-4" stroke="currentColor" strokeWidth={2}>
                  <path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0l-1 14a2 2 0 01-2 2H7a2 2 0 01-2-2L4 6h16z" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
