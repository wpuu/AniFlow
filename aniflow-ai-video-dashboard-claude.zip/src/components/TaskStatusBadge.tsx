import type { TaskStatus } from "../types";
import { cn } from "../utils/cn";

const CONFIG: Record<TaskStatus, { label: string; className: string }> = {
  queued: { label: "等待中", className: "bg-slate-500/15 text-slate-300 border-slate-400/30" },
  processing: { label: "生成中", className: "bg-indigo-500/15 text-indigo-300 border-indigo-400/30" },
  completed: { label: "已完成", className: "bg-emerald-500/15 text-emerald-300 border-emerald-400/30" },
  failed: { label: "失败", className: "bg-rose-500/15 text-rose-300 border-rose-400/30" },
};

export default function TaskStatusBadge({ status }: { status: TaskStatus }) {
  const c = CONFIG[status];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium", c.className)}>
      {status === "processing" && (
        <svg className="h-3 w-3 animate-spin" viewBox="0 0 24 24" fill="none">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
        </svg>
      )}
      {status === "queued" && (
        <svg className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
          <circle cx="12" cy="12" r="9" />
          <path d="M12 7v5l3 3" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )}
      {status === "completed" && (
        <svg className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
          <path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )}
      {status === "failed" && (
        <svg className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
          <path d="M6 18L18 6M6 6l12 12" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )}
      {c.label}
    </span>
  );
}
