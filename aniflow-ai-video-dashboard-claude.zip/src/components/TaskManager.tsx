import { useMemo, useState } from "react";
import type { TaskStatus, VideoTask } from "../types";
import TaskCard from "./TaskCard";

interface TaskManagerProps {
  tasks: VideoTask[];
  onPlay: (task: VideoTask) => void;
  onViewParams: (task: VideoTask) => void;
  onCancel: (id: string) => void;
  onRetry: (task: VideoTask) => void;
  onRemove: (id: string) => void;
}

type FilterKey = "all" | TaskStatus;

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: "all", label: "全部" },
  { key: "queued", label: "等待" },
  { key: "processing", label: "生成中" },
  { key: "completed", label: "完成" },
  { key: "failed", label: "失败" },
];

export default function TaskManager({ tasks, onPlay, onViewParams, onCancel, onRetry, onRemove }: TaskManagerProps) {
  const [filter, setFilter] = useState<FilterKey>("all");

  const counts = useMemo(() => {
    const c: Record<FilterKey, number> = { all: tasks.length, queued: 0, processing: 0, completed: 0, failed: 0 };
    for (const t of tasks) c[t.status]++;
    return c;
  }, [tasks]);

  const filtered = useMemo(() => {
    const list = filter === "all" ? tasks : tasks.filter((t) => t.status === filter);
    return [...list].sort((a, b) => b.createdAt - a.createdAt);
  }, [tasks, filter]);

  return (
    <section className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-sm font-semibold tracking-wide text-white">任务管理</h2>
        <div className="flex flex-wrap gap-1.5">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
                filter === f.key
                  ? "bg-gradient-to-r from-indigo-500 to-fuchsia-500 text-white shadow shadow-indigo-500/20"
                  : "bg-white/5 text-slate-400 hover:bg-white/10 hover:text-slate-200"
              }`}
            >
              {f.label}
              <span className="ml-1 opacity-70">{counts[f.key]}</span>
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-white/10 py-16 text-center">
          <svg viewBox="0 0 24 24" fill="none" className="h-8 w-8 text-slate-600" stroke="currentColor" strokeWidth={1.5}>
            <rect x="2" y="4" width="20" height="16" rx="2" />
            <path d="M10 4v4M2 8h20M6 4v4" />
          </svg>
          <p className="text-sm text-slate-500">暂无任务，去上方创建你的第一个视频吧</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {filtered.map((t) => (
            <TaskCard
              key={t.id}
              task={t}
              onPlay={onPlay}
              onViewParams={onViewParams}
              onCancel={onCancel}
              onRetry={onRetry}
              onRemove={onRemove}
            />
          ))}
        </div>
      )}
    </section>
  );
}
