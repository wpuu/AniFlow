import { MODELS } from "../data/models";
import type { VideoTask } from "../types";
import { formatCost } from "../utils/format";

export default function VideoModal({ task, onClose }: { task: VideoTask; onClose: () => void }) {
  const model = MODELS.find((m) => m.id === task.params.modelId);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl overflow-hidden rounded-2xl border border-white/10 bg-[#11131f] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-3.5">
          <p className="truncate pr-4 text-sm font-medium text-white">{task.params.prompt}</p>
          <button onClick={onClose} className="shrink-0 rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white">
            <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5" stroke="currentColor" strokeWidth={2}>
              <path d="M6 18L18 6M6 6l12 12" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>

        <div className="bg-black">
          {task.videoUrl && (
            <video src={task.videoUrl} controls autoPlay className="max-h-[70vh] w-full" poster={task.thumbnailUrl} />
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 text-xs text-slate-400">
          <span>
            {model?.providerName} · {model?.name} · {task.params.aspectRatio} · {task.params.durationSec}s
          </span>
          <div className="flex items-center gap-3">
            <span>成本 {formatCost(task.cost)}</span>
            <a
              href={task.videoUrl}
              download={`aniflow-${task.id}.mp4`}
              className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 font-medium text-slate-200 transition hover:bg-white/10"
            >
              下载视频
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
