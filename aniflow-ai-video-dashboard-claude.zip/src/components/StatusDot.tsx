import { cn } from "../utils/cn";
import type { BackendStatus } from "../types";

const STYLES: Record<BackendStatus, { dot: string; text: string; label: string; ring: string }> = {
  online: {
    dot: "bg-emerald-400",
    text: "text-emerald-400",
    label: "在线",
    ring: "shadow-[0_0_10px_rgba(52,211,153,0.7)]",
  },
  degraded: {
    dot: "bg-amber-400",
    text: "text-amber-400",
    label: "延迟",
    ring: "shadow-[0_0_10px_rgba(251,191,36,0.7)]",
  },
  offline: {
    dot: "bg-rose-500",
    text: "text-rose-400",
    label: "离线",
    ring: "shadow-[0_0_10px_rgba(244,63,94,0.7)]",
  },
};

export default function StatusDot({
  status,
  showLabel = true,
  className,
}: {
  status: BackendStatus;
  showLabel?: boolean;
  className?: string;
}) {
  const s = STYLES[status];
  return (
    <span className={cn("inline-flex items-center gap-1.5", className)}>
      <span className={cn("relative inline-flex h-2 w-2 rounded-full", s.dot, s.ring)}>
        {status === "online" && (
          <span className={cn("absolute inline-flex h-full w-full animate-ping rounded-full opacity-60", s.dot)} />
        )}
      </span>
      {showLabel && <span className={cn("text-xs font-medium", s.text)}>{s.label}</span>}
    </span>
  );
}
