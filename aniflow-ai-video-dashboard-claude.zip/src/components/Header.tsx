import type { BackendStatus } from "../types";
import StatusDot from "./StatusDot";

export default function Header({
  overallStatus,
  activeJobs,
}: {
  overallStatus: BackendStatus;
  activeJobs: number;
}) {
  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-[#0b0d14]/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-[1400px] items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600 shadow-lg shadow-fuchsia-500/20">
            <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5 text-white" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
          </div>
          <div className="leading-tight">
            <h1 className="text-[15px] font-semibold tracking-tight text-white">
              AniFlow
            </h1>
            <p className="text-[11px] text-slate-400">个人 AI 视频生产工作台</p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-4">
          <div className="hidden items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 sm:flex">
            <span className="text-xs text-slate-400">系统状态</span>
            <StatusDot status={overallStatus} />
          </div>

          <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-indigo-400 opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-indigo-400" />
            </span>
            <span className="text-xs text-slate-300">
              运行中任务 <span className="font-semibold text-white">{activeJobs}</span>
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
