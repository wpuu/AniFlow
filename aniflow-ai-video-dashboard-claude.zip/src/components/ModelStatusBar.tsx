import { MODELS } from "../data/models";
import type { BackendStatus, ModelInfo, ProviderId } from "../types";
import StatusDot from "./StatusDot";
import { formatCost } from "../utils/format";

interface ProviderSummary {
  id: ProviderId;
  name: string;
  status: BackendStatus;
  latencyMs: number;
  queueLength: number;
  modelCount: number;
}

const STATUS_RANK: Record<BackendStatus, number> = { online: 0, degraded: 1, offline: 2 };

function summarizeProviders(): ProviderSummary[] {
  const map = new Map<ProviderId, ProviderSummary>();
  for (const m of MODELS) {
    const existing = map.get(m.providerId);
    if (!existing) {
      map.set(m.providerId, {
        id: m.providerId,
        name: m.providerName,
        status: m.status,
        latencyMs: m.latencyMs,
        queueLength: m.queueLength,
        modelCount: 1,
      });
    } else {
      existing.modelCount += 1;
      existing.queueLength += m.queueLength;
      existing.latencyMs = Math.max(existing.latencyMs, m.latencyMs);
      if (STATUS_RANK[m.status] > STATUS_RANK[existing.status]) existing.status = m.status;
    }
  }
  return Array.from(map.values());
}

export default function ModelStatusBar({ currentModel }: { currentModel: ModelInfo }) {
  const providers = summarizeProviders();

  return (
    <section className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {providers.map((p) => (
        <div
          key={p.id}
          className="rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-white/20"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium uppercase tracking-wider text-slate-400">{p.name}</span>
            <StatusDot status={p.status} />
          </div>
          <div className="mt-3 flex items-end justify-between">
            <div>
              <p className="text-lg font-semibold text-white">
                {p.status === "offline" ? "—" : `${p.latencyMs}ms`}
              </p>
              <p className="text-[11px] text-slate-500">响应延迟</p>
            </div>
            <div className="text-right">
              <p className="text-lg font-semibold text-white">{p.queueLength}</p>
              <p className="text-[11px] text-slate-500">排队任务</p>
            </div>
          </div>
        </div>
      ))}

      <div className="rounded-2xl border border-indigo-400/30 bg-gradient-to-br from-indigo-500/10 to-fuchsia-500/10 p-4 sm:col-span-2 lg:col-span-1">
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium uppercase tracking-wider text-indigo-300">当前模型</span>
          <StatusDot status={currentModel.status} />
        </div>
        <p className="mt-3 truncate text-lg font-semibold text-white">{currentModel.name}</p>
        <p className="truncate text-[11px] text-slate-400">{currentModel.providerName}</p>
        <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
          <span>{formatCost(currentModel.costPerSecond)}/秒</span>
          <span>最长 {currentModel.maxDurationSec}s</span>
        </div>
      </div>
    </section>
  );
}
