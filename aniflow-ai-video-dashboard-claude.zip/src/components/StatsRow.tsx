import type { VideoTask } from "../types";
import { formatCost } from "../utils/format";

export default function StatsRow({ tasks }: { tasks: VideoTask[] }) {
  const completed = tasks.filter((t) => t.status === "completed");
  const totalCost = tasks.reduce((sum, t) => sum + t.cost, 0);
  const successRate = tasks.length
    ? Math.round((completed.length / tasks.filter((t) => t.status === "completed" || t.status === "failed").length || 0) * 100)
    : 0;

  const stats = [
    { label: "累计生成视频", value: `${completed.length}` },
    { label: "累计花费", value: formatCost(totalCost) },
    { label: "成功率", value: `${Number.isFinite(successRate) ? successRate : 0}%` },
    { label: "进行中任务", value: `${tasks.filter((t) => t.status === "queued" || t.status === "processing").length}` },
  ];

  return (
    <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {stats.map((s) => (
        <div key={s.label} className="rounded-xl border border-white/10 bg-white/[0.02] px-4 py-3 text-center">
          <p className="text-xl font-semibold text-white">{s.value}</p>
          <p className="mt-0.5 text-[11px] text-slate-500">{s.label}</p>
        </div>
      ))}
    </section>
  );
}
