import { MODELS } from "../data/models";
import type { VideoTask } from "../types";
import { formatCost, formatTime } from "../utils/format";

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-white/5 py-2.5 last:border-0">
      <span className="shrink-0 text-xs text-slate-500">{label}</span>
      <span className="break-words text-right text-xs text-slate-200">{value}</span>
    </div>
  );
}

export default function ParamsModal({ task, onClose }: { task: VideoTask; onClose: () => void }) {
  const model = MODELS.find((m) => m.id === task.params.modelId);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md overflow-hidden rounded-2xl border border-white/10 bg-[#11131f] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-3.5">
          <p className="text-sm font-semibold text-white">生成参数</p>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white">
            <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5" stroke="currentColor" strokeWidth={2}>
              <path d="M6 18L18 6M6 6l12 12" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>

        <div className="max-h-[70vh] overflow-y-auto px-5 py-2">
          <Row label="任务 ID" value={task.id} />
          <Row label="模型" value={`${model?.providerName} · ${model?.name}`} />
          <Row label="提示词" value={task.params.prompt} />
          <Row label="反向提示词" value={task.params.negativePrompt || "—"} />
          <Row label="首帧图片" value={task.params.firstFrameName || "未使用"} />
          <Row label="视频比例" value={task.params.aspectRatio} />
          <Row label="时长" value={`${task.params.durationSec} 秒`} />
          <Row label="随机种子 Seed" value={task.params.seed} />
          <Row label="创建时间" value={formatTime(task.createdAt)} />
          <Row label="完成时间" value={task.status === "completed" || task.status === "failed" ? formatTime(task.updatedAt) : "—"} />
          <Row label="生成成本" value={formatCost(task.cost)} />
          <Row label="状态" value={task.status} />
          {task.errorMessage && <Row label="错误信息" value={task.errorMessage} />}
        </div>
      </div>
    </div>
  );
}
